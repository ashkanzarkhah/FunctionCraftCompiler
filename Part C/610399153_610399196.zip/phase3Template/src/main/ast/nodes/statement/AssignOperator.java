package main.ast.nodes.statement;

public enum AssignOperator {
    ASSIGN, PLUS_ASSIGN, MINUS_ASSIGN, DIVIDE_ASSIGN, MULT_ASSIGN, MOD_ASSIGN
}
